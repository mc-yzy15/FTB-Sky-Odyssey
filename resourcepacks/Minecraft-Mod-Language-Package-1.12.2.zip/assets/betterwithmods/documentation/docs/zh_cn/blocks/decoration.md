装饰性方块

![木桌](block:betterwithmods:wood_table@1)

木桌是一种由上部满格的桌面和下部的一条桌腿组成的装饰性方块

![木凳](block:betterwithmods:wood_bench@1)

木凳除了桌腿只有半块以外和木桌没什么两样
 
![木质板条栅栏](block:betterwithmods:slats@1)

板条栅栏是一种拥有着所有原版木板的变种并有玻璃的碰撞箱的装饰性方块

![木质网络格栏](block:betterwithmods:grate@1)

板条格栏是一种拥有着所有原版木板的变种并有玻璃的碰撞箱的装饰性方块

![篦板](block:betterwithmods:wicker)

篦板是一种有着玻璃的碰撞箱的装饰性方块

![Wicker Block](block:betterwithmods:aesthetic@12)

篦板块除了是一个完整方块以外和篦板并没有什么区别